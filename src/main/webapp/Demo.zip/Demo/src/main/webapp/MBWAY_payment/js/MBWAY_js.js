function getURLParameter(name) {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(name);
}


document.addEventListener("DOMContentLoaded", async function () {

  // variavies globais
  const timerElement = document.getElementById("timer");
  const messageElement = document.getElementById("message");
  const buttonElement = document.getElementById("btnComParametros_button");
  const statusList = document.getElementById("statusList");

  const totalTime = 240;
  const delayAfterExpiration = 60 * 1000;
  let timerInterval;

  const urlParams = new URLSearchParams(window.location.search);
  const currentTransactionID = urlParams.get("id");

  const useDefault = JSON.parse(localStorage.getItem("default"));
  const credential_default_variable = JSON.parse(localStorage.getItem('credential_default'))

  let encodedPaymentMethods

  const token = credential_default_variable.bearerToken;
  const clientId = credential_default_variable.clientId;
  const terminalId = credential_default_variable.terminalId;
  const entity = credential_default_variable.entity;
  const isDummyCustomer = credential_default_variable.isDummyCustomer;
  const ServerToServer = credential_default_variable.ServerToServer;
  const paymentMethods= credential_default_variable.paymentMethods;
  
  
  encodedPaymentMethods = encodeURIComponent(paymentMethods);

  function showMessage(text, type) {
    messageElement.textContent = text;
    messageElement.classList.remove("d-none", "alert-danger", "alert-success", "alert-warning");
    messageElement.classList.add("alert-" + type);
    buttonElement.classList.remove("d-none");
  }

  //Função que irá fazer o getstatus da transação MB WAY e ver em qual estado esta o pagamento para colocar a mensagem certa na tela do utilizador
  async function checkRemotePaymentStatus() {

    const token_payment = credential_default_variable.bearerToken;
    const clientId_payment = credential_default_variable.clientId;
    const gatewayVersion = credential_default_variable.gatewayVersion;
    

    const version = gatewayVersion === "1" ? "v1" : "v2";
    const apiUrl = `https://spg.qly.site1.sibs.pt/api/${version}/payments/${currentTransactionID}/status`;

    const headers = {
      Authorization: `Bearer ${token_payment}`,
      "X-IBM-Client-Id": clientId_payment,
      "Content-Type": "application/json",
      "Accept": "application/json"
    };

    try {
      const response = await fetch(apiUrl, { method: "GET", headers });
      if (!response.ok) throw new Error(`Erro na requisição: ${response.status}`);

      let responseHeadersObj = {};
      response.headers.forEach((value, key) => {
        responseHeadersObj[key] = value;
      });

      const data = await response.json();

      if(data.transactionStatusCode == "000") data.transactionStatusCode = "200"

        
      if (data.paymentStatus === "Declined" && data.transactionStatusCode == "E0506") {
        const timerParagraph = document.querySelector('p');
        if (timerParagraph) timerParagraph.style.display = "none";
          messageElement.textContent = 'O número colocado não está registado no MB WAY.';
          messageElement.classList.remove("d-none");
          messageElement.classList.add("alert", "alert-danger");
          buttonElement.classList.add("d-none");
          return { success: false, status: data.paymentStatus };
      }


      if (data.paymentStatus === "Success") {
        document.getElementById("timer").parentElement.style.display = "none";
        messageElement.classList.add("d-none");
        statusList.innerHTML = `
          <div class="alert alert-success" role="alert">
            <strong>Estado do Pagamento:</strong> Sucesso
          </div>`;
        return { success: true, status: data.paymentStatus };
      }

        
      if (data.paymentStatus === "Declined") {
        document.getElementById("timer").parentElement.style.display = "none";
        messageElement.classList.add("d-none");

        let mensagem = "Recusado";

        if (data.transactionStatusCode === "E0500") {
            mensagem = "Recusado (Cliente não efetuou o pagamento na APP)";
        }

        if (data.transactionStatusCode === "E9999") {
            mensagem = "Recusado, por favor tente novamente";
        }

        statusList.innerHTML = `
          <div class="alert alert-danger" role="alert">
            <strong>Estado do Pagamento:</strong> ${mensagem}
          </div>`;

        return { success: false, status: data.paymentStatus };
      }


      return { success: false, status: data.paymentStatus };
      
    } catch (error) {
      console.error("Erro ao buscar status remoto:", error);
      return true;
    }
  }

  //Função que irá fazer novamente o get status por uma segunda vez apos os 4 minutos expirar
  async function checkFinalPaymentStatus() {
    try {

      let token_payment
      let clientId_payment
      let gatewayVersion

      token_payment = credential_default_variable.bearerToken;
      clientId_payment = credential_default_variable.clientId;
      gatewayVersion = credential_default_variable.gatewayVersion;
      

      const version = gatewayVersion === "1" ? "v1" : "v2";
      const apiUrl = `https://spg.qly.site1.sibs.pt/api/${version}/payments/${currentTransactionID}/status`;

      const headers = {
        Authorization: `Bearer ${token_payment}`,
        "X-IBM-Client-Id": clientId_payment,
        "Content-Type": "application/json",
        "Accept": "application/json"
      };

      const response = await fetch(apiUrl, { method: "GET", headers });

      let responseHeadersObj = {};
      response.headers.forEach((value, key) => {
        responseHeadersObj[key] = value;
      });

      const data = await response.json();
      
      if(data.transactionStatusCode == "000") data.transactionStatusCode = "200"

      messageElement.classList.add("d-none");

      let statusHTML = '';
      if (data.paymentStatus === 'Pending') {
        statusHTML = `<li class="list-group-item text-warning"><strong>Estado do Pagamento:</strong> Pendente</li>`;
      } else if (data.paymentStatus === 'Declined') {
        statusHTML = `<li class="list-group-item text-danger"><strong>Estado do Pagamento:</strong> Recusado</li>`;
      } else if (data.paymentStatus === 'Success') {
        statusHTML = `<li class="list-group-item text-success"><strong>Estado do Pagamento:</strong> Sucesso</li>`;
      } else {
        statusHTML = `<li class="list-group-item"><strong>Estado do Pagamento:</strong> ${data.paymentStatus}</li>`;
      }

      statusList.innerHTML = statusHTML;

    } catch (e) {
      console.error("Erro ao consultar status após o timeout:", e);
    }
  }

  async function checkImmediateStatus() {
    try {
      const res = await fetch("/status-pagamento");
      const data = await res.json();

      if (data.status === "concluido") {
        clearInterval(timerInterval);
        showMessage("Pagamento efetuado com sucesso!", "success");
        timerElement.textContent = "Pagamento concluído!";
        localStorage.removeItem("startTime");
        localStorage.removeItem("timerExpired");
      }
    } catch (e) {
      console.error("Erro ao verificar status inicial:", e);
    }
  }

  // É o que vai fazer o update ao timer quando tiver a zero e determinar o fluxo do MB WAY
  async function updateTimer(canStartTimer) {
    const now = Date.now();
    const elapsed = Math.floor((now - startTime) / 1000);
    const timeLeft = totalTime - elapsed;
    const dataSafe = typeof data !== 'undefined' ? data : {};

    if (timeLeft <= 0 ) {
      timerElement.textContent = "0:00";
      clearInterval(timerInterval);
      const canStartTimer = await checkRemotePaymentStatus();
      if(canStartTimer.status == 'Pending'){
        showMessage("O pagamento no MB WAY expirou.", "warning");
        localStorage.setItem("timerExpired", "true");
        setTimeout(checkFinalPaymentStatus, delayAfterExpiration);
      }
        
    } else {
      const minutes = Math.floor(timeLeft / 60);
      const seconds = timeLeft % 60;
      timerElement.textContent = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
    }
  }

  // --- FLUXO PRINCIPAL ---
  const storedTransactionID = localStorage.getItem("transactionID");
  if (!storedTransactionID || storedTransactionID !== currentTransactionID) {
    localStorage.setItem("transactionID", currentTransactionID);
    localStorage.setItem("startTime", Date.now());
    localStorage.removeItem("timerExpired");
  }

  let startTime = parseInt(localStorage.getItem("startTime"), 10);
  if (isNaN(startTime)) {
    startTime = Date.now();
    localStorage.setItem("startTime", startTime);
  }

  const isExpired = localStorage.getItem("timerExpired") === "true";
  const canStartTimer = await checkRemotePaymentStatus();
  const dataSafe = typeof data !== 'undefined' ? data : {};

  if (!canStartTimer) return;

  if (isExpired) {
    timerElement.textContent = "0:00";
    if(canStartTimer.status == 'Pending'){
      showMessage("O pagamento no MB WAY expirou.", "warning");
      setTimeout(checkFinalPaymentStatus, delayAfterExpiration);
    }
  } else {
    const elapsed = Math.floor((Date.now() - startTime) / 1000);
    if (elapsed >= totalTime) {
      timerElement.textContent = "0:00";
      if(canStartTimer.status == 'Pending'){
        showMessage("O pagamento no MB WAY expirou.", "warning");
        localStorage.setItem("timerExpired", "true");
        setTimeout(checkFinalPaymentStatus, delayAfterExpiration);
      }
    } else {
      timerInterval = setInterval(updateTimer, 1000);
      updateTimer(canStartTimer);
      checkImmediateStatus();
    }
  }
});
