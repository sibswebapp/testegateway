//Buscar localStorage arrays
const credential_default_variable = JSON.parse(localStorage.getItem('credential_default'))
  
//Se ele clicar voltar para tras isto da reset a tudo
window.addEventListener('pageshow', function(event) {
  if (event.persisted || performance.getEntriesByType("navigation")[0].type === "back_forward") {
    const dynamicForm = document.getElementById("dynamicForm");
    
    if (dynamicForm) dynamicForm.remove();
    const forms = document.querySelectorAll("form");
    forms.forEach(form => form.reset());
    window.location.reload();
  }
});

document.addEventListener("DOMContentLoaded", function () {

  let paymentMethodsParam;

  paymentMethodsParam = credential_default_variable.paymentMethods
  AllMethodsPay = credential_default_variable.AllMethodsPay
  gatewayVersion = credential_default_variable.gatewayVersion
  LayoutVersion = credential_default_variable.LayoutVersion

  if (AllMethodsPay == "1") {
    document.getElementById("payment-method_Div").style.display = "none";
  } else {
    document.getElementById("payment-method_Div").style.display = "block";
  }

  const select = document.getElementById("payment-method");
  select.innerHTML = "";

  const methodMap = {
    "1": { label: "MB WAY", value: "MBWAY" },
    "2": { label: "Multibanco", value: "REFERENCE" },
    "3": { label: "Cartão", value: "CARD" }
  };

  if (paymentMethodsParam) {

    //verificar se é string e converter
    if (typeof paymentMethodsParam === "string") {
      try {
        paymentMethodsParam = JSON.parse(paymentMethodsParam);
      } catch {
        paymentMethodsParam = paymentMethodsParam.split(",");
      }
    }

    paymentMethodsParam
      .filter(code => typeof code === "string")
      .forEach(code => {
        const trimmed = code.trim();
        if (methodMap[trimmed]) {
          const opt = document.createElement("option");
          opt.value = methodMap[trimmed].value;
          opt.textContent = methodMap[trimmed].label;
          select.appendChild(opt);
        }
      });
    }

    if (select.options.length === 0) {
      Object.values(methodMap).forEach(({ label, value }) => {
        const opt = document.createElement("option");
        opt.value = value;
        opt.textContent = label;
        select.appendChild(opt);
      });
    }
  });

  function getURLParameter(name) {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(name);
  }

  //função que faz o costumer info personalizado aparecer
  function showDummyFieldsIfNeeded() {

    const isDummyCustomer = credential_default_variable.isDummyCustomer
    const selectedMethod = document.getElementById("payment-method").value;

    if (isDummyCustomer === "1" && selectedMethod == "CARD") {
      document.getElementById("dummyCustomerFields").style.display = "block";
    } else {
      document.getElementById("dummyCustomerFields").style.display = "none";
    }
  }

  window.addEventListener("DOMContentLoaded", showDummyFieldsIfNeeded);

  function validateDummyCustomerFields() {
   
    const isDummyCustomer = credential_default_variable.isDummyCustomer
    
    if (isDummyCustomer !== "1") {
      return true;
    }

    const container = document.getElementById("dummyCustomerFields");
    if (!container) return true;

    const inputs = container.querySelectorAll("input, select");

    for (const input of inputs) {
      if (!input.value || input.value.trim() === "") {
        input.focus();
        return false;
      }
    }

    return true;
  }

  //função que faz o pagamento (checkout)
  async function makePayment() {

    let apiUrl;

    const  token = credential_default_variable.bearerToken;
    const  clientId = credential_default_variable.clientId;
    const  terminalId = parseInt(credential_default_variable.terminalId);
    const  entity = String(credential_default_variable.entity);
    const  referenceExpiry = credential_default_variable.referenceExpiry;
    const  referenceExpiryUnit = credential_default_variable.referenceExpiryUnit;
    const  gatewayVersion = credential_default_variable.gatewayVersion;
    const  LayoutVersion = credential_default_variable.LayoutVersion
    
    const amountValue = parseFloat(document.getElementById("amount").value);
    const selectedMethod = document.getElementById("payment-method").value;


    //caso o AllMethodsPay tiver a 1 então o array do payment Method fica vazio
    const paymentMethodArray = (AllMethodsPay == "1") ? [] : [selectedMethod];

    const version = gatewayVersion === "1" ? "v1" : "v2";
    apiUrl = `https://spg.qly.site1.sibs.pt/api/${version}/payments`;

    if (!validateDummyCustomerFields()) {
      return;
    }

    const initialDatetime = new Date();
    const initialDatetimeStr = initialDatetime.toISOString();

    const finalDatetime = new Date(initialDatetime);

    // força número
    const expiryValue = parseInt(referenceExpiry, 10);
    const unit = String(referenceExpiryUnit || "").toLowerCase();

    if (!isNaN(expiryValue) && expiryValue > 0) {
      switch (unit) {
        case "hours":
          finalDatetime.setHours(initialDatetime.getHours() + expiryValue);
          break;

        case "days":
          finalDatetime.setDate(initialDatetime.getDate() + expiryValue);
          break;

        case "months":
          // usa setFullYear para evitar overflow e bug de string
          finalDatetime.setFullYear(
          initialDatetime.getFullYear(),
          initialDatetime.getMonth() + expiryValue,
          initialDatetime.getDate()
          );
          break;

        default:
          console.warn("Unidade de expiração desconhecida:", referenceExpiryUnit);
          break;
      }
    } else {
        finalDatetime.setFullYear(
        initialDatetime.getFullYear(),
        initialDatetime.getMonth() + 2,
        initialDatetime.getDate()
      );
    }

    const finalDatetimeStr = finalDatetime.toISOString();

    const requestData = {
      merchant: {
        terminalId: terminalId,
        channel: "web",
        merchantTransactionId: "OrderID"
      },
      transaction: {
        transactionTimestamp: new Date().toISOString(),
        description: "Transaction short description",
        moto: false,
        paymentType: "PURS",
        amount: {
          value: amountValue,
          currency: "EUR"
        },
        paymentMethod: paymentMethodArray,
        paymentReference: {
          initialDatetime: initialDatetimeStr,
          finalDatetime: finalDatetimeStr,
          maxAmount: { value: amountValue, currency: "EUR" },
          minAmount: { value: amountValue, currency: "EUR" },
          entity: entity
        }
      }
    };

    const isDummyCustomer = credential_default_variable.isDummyCustomer
    
    if (isDummyCustomer === "1" && selectedMethod == "CARD") {
      requestData.customer = {
        customerInfo: {
          customerName: document.getElementById("customerName").value,
          customerEmail: document.getElementById("customerEmail").value
          
        }
      };
    }

    let response;
    let data;

    try {
      response = await fetch(apiUrl, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${token}`,
          "X-IBM-Client-Id": clientId,
          "Content-Type": "application/json",
          "Accept": "application/json"
        },
        body: JSON.stringify(requestData)
      });

      if (!response.ok) {
        throw new Error(`Erro na requisição: ${response.status}`);
      }

      data = await response.json();

      if (data.transactionID && data.formContext) {
        generatePaymentForm(
          data.transactionID,
          data.formContext,
          data.transactionSignature,
          data,
          paymentMethodArray
        );
      } else {
        throw new Error("Resposta da API incompleta.");
      }

    } catch (error) {
      console.error("Erro ao processar pagamento:", error);
    }

  }

  //função que gera o form (logo a seguir ao checkout)
  function generatePaymentForm(transactionID, formContext, transactionSignature, data, paymentMethodArray) {
    const formContainer = document.getElementById("payment-form");
    formContainer.innerHTML = "";

    let apiUrl;
    let version;

    const token_payment = credential_default_variable.bearerToken;
    const clientId_payment = credential_default_variable.clientId;
    const terminalId_payment = parseInt(credential_default_variable.terminalId);
    const entity_payment = String(credential_default_variable.entity);
    let LayoutVersion = credential_default_variable.LayoutVersion;
    const isDummyCustomer = credential_default_variable.isDummyCustomer;
    const paymentMethods = credential_default_variable.paymentMethods;
    const isServerToServer =  credential_default_variable.ServerToServer;
    const gatewayVersion = credential_default_variable.gatewayVersion;

    let baseUrl = window.location.origin + '/';

    let redirectUrl = `${baseUrl}reference_payment/REFERENCE_return.html`

    if (paymentMethodArray.length === 1 && paymentMethodArray[0] === "MBWAY") {
      redirectUrl = `${baseUrl}MBWAY_payment/MBWAY_return.html`
    }

    if (paymentMethodArray.length === 1 && paymentMethodArray[0] === "CARD") {
      redirectUrl = `${baseUrl}card_payment/card_return.html`
    }

    if (paymentMethodArray.length == 0) {
      redirectUrl = `${baseUrl}AllmethodsPayment/AllmethodsPayment.html`
    }


    const amount = parseFloat(document.getElementById("amount").value);
    const form = document.createElement("form");
    form.className = "paymentSPG";

    form.setAttribute("spg-context", formContext);
        
    form.setAttribute("spg-config", JSON.stringify({
      paymentMethodList: [],
      amount: { value: amount, currency: "EUR" },
      language: "pt",
      redirectUrl: redirectUrl
    }));

    if(LayoutVersion){
      
      if(LayoutVersion == "1") LayoutVersion = "spg_form"
      if(LayoutVersion == "2") LayoutVersion = "spg_form_tabs"

      form.setAttribute("spg-style", JSON.stringify({
        layout: LayoutVersion,
        theme: "default",
        color: {
                "primary": "",
                "border": "",
                "surface": "",
                "body": {
                  "text": "",
                }
        },
          font: ""
      }));

    }

    formContainer.appendChild(form);

    const script = document.createElement("script");
    script.src = `https://spg.qly.site1.sibs.pt/assets/js/widget.js?id=${transactionID}`;
    document.body.appendChild(script);

    const token = credential_default_variable.bearerToken;
    const clientId = credential_default_variable.clientId;
    const terminalId = parseInt(credential_default_variable.terminalId);
    const entity = String(credential_default_variable.entity);
     
  }

  const currentDefault = localStorage.getItem('default');
  const terminalToggle = document.getElementById('defaultToggle');

  if (terminalToggle) {
    terminalToggle.checked = currentDefault === '1';
  }

