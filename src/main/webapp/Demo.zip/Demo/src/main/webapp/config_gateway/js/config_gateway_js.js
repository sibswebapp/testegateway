// PopUP de sucesso chamada
const successModal = document.getElementById("successModal"),
      overlay = successModal.querySelector(".overlay"),
      closeBtn = successModal.querySelector(".close-btn");

function showSuccessModal() {
  successModal.classList.add("active");
}

overlay.addEventListener("click", () => successModal.classList.remove("active"));
closeBtn.addEventListener("click", () => successModal.classList.remove("active"));


// PopUP de erro chamada
const errorModal = document.getElementById("errorModal"),
      errorOverlay = errorModal.querySelector(".overlay"),
      errorCloseBtn = errorModal.querySelector(".close-btn");

function showErrorModal(message) {
  errorMessage.textContent = message;
  errorModal.classList.add("active");
}

errorOverlay.addEventListener("click", () => errorModal.classList.remove("active"));
errorCloseBtn.addEventListener("click", () => errorModal.classList.remove("active"));


//Buscar localStorage arrays
const credentialDefaultObj = JSON.parse(localStorage.getItem('credential_default'));
const credential_config_variable = JSON.parse(localStorage.getItem('credential_config'))
const default_Configs = JSON.parse(localStorage.getItem('default'))
    

function getSelectedPaymentMethods() {
  let selectedOptions = Array.from(document.getElementById("paymentMethods").selectedOptions)
                      .map(opt => opt.value);

  if (selectedOptions.length === 0) {
    if (credential_config_variable && credential_config_variable.paymentMethods && credential_config_variable.paymentMethods.length > 0) {
      try {
        selectedOptions = JSON.parse(credential_config_variable.paymentMethods);
      } catch (e) {
        selectedOptions = credential_config_variable.paymentMethods;
      }
    } else {
      selectedOptions = credential_default_variable.paymentMethods;
    }
  }

  return selectedOptions;

}


// handler para os vários métodos de pagamento
function handlePaymentMethodChange() {
  const selectedOptions = getSelectedPaymentMethods();

  const hasCardSelected = selectedOptions.includes("3") || selectedOptions.includes("CARD");
  const hasMultibancoSelected = selectedOptions.includes("2") || selectedOptions.includes("REFERENCE");
  const toggleContainer = document.getElementById("dummyCustomerToggleContainer");
  const inputReferenceExpiry = document.getElementById("inputReferenceExpiry");

  toggleContainer.style.display = hasCardSelected ? "block" : "none";

  if (hasMultibancoSelected) {
    inputReferenceExpiry.classList.remove("d-none");
  } else {
    inputReferenceExpiry.classList.add("d-none");
  }
}

//Função caso ele selecione a opção de todos os metodos de pagamento
function toggleAllMethodsPay(element) {
  const CheckAllMethodsPay = element.checked ? 1 : 0;
  const paymentMethodsContainer = document.getElementById("paymentMethodsContainer");
  const paymentMethodsLabels = document.getElementById("paymentMethodsLabels");
  const paymentMethodsText = document.getElementById("paymentMethodsText");

  if (CheckAllMethodsPay) {
    paymentMethodsContainer.style.display = "none";
    paymentMethodsLabels.style.display = "none";
    paymentMethodsText.style.display = "none";

    document.getElementById("dummyCustomerToggleContainer").style.display = "none";
    inputReferenceExpiry.classList.remove("d-none");

  } else {
    paymentMethodsContainer.style.display = "block";
    paymentMethodsLabels.style.display = "block";
    paymentMethodsText.style.display = "block";
    paymentMethods.style.display = "block";

    document.getElementById("dummyCustomerToggleContainer").style.display = "block";
    handlePaymentMethodChange();
  }
}

function toggleAllMethodsPayRestored(AllMethodsPay) {
      
  const checkbox = document.getElementById("AllMethodsPay");
  const paymentContainer = document.getElementById("paymentMethodsContainer");
  const paymentMethodsLabels = document.getElementById("paymentMethodsLabels");
  const paymentMethodsText = document.getElementById("paymentMethodsText");

  if (AllMethodsPay == 1) {
    checkbox.checked = true;
    paymentContainer.style.display = "none";
    paymentMethodsLabels.style.display = "none";
    paymentMethodsText.style.display = "none";
    document.getElementById("dummyCustomerToggleContainer").style.display = "none";
    inputReferenceExpiry.classList.remove("d-none");
  } else {
    checkbox.checked = false;
    paymentContainer.style.display = "block";
    paymentMethodsLabels.style.display = "block";
    paymentMethodsText.style.display = "block";
    document.getElementById("dummyCustomerToggleContainer").style.display = "block";
    handlePaymentMethodChange();
  }
}


// Para selecionar a checkbox do Customer info personalizado
function toggleDummyCustomer(element) {
  isDummyCustomer = element.checked ? 1 : 0;
  localStorage.setItem('isDummyCustomer', isDummyCustomer.toString());
}

window.addEventListener('DOMContentLoaded', () => {

  const storedDummy = localStorage.getItem('isDummyCustomer');
    if (storedDummy !== null) {
      isDummyCustomer = parseInt(storedDummy);
      const checkbox = document.getElementById('dummyCustomerToggle');
      if (checkbox) checkbox.checked = isDummyCustomer === 1;
    }
});

//Salvar opções
function saveConfig() {

  let referenceExpiry = document.getElementById("referenceExpiry").value.trim();
  let referenceExpiryUnit = document.getElementById("referenceExpiryUnit").value;
  let isDummyCustomer = document.getElementById('dummyCustomerToggle').checked ? 1 : 0;
  let LayoutVersion = document.getElementById("LayoutVersion").value;

  const methods = Array.from(document.getElementById('paymentMethods').selectedOptions).map(opt => opt.value);
  const AllMethodsPay = document.getElementById('AllMethodsPay').checked ? 1 : 0;

  if(AllMethodsPay){
    isDummyCustomer = 0;
  }

  if(!methods.includes('2') && !AllMethodsPay){
    referenceExpiry = "";
    referenceExpiryUnit = "days";
  }

  if (referenceExpiry === "" || isNaN(referenceExpiry)) {
    showErrorModal("O tempo de expiração deve ser um número válido e não pode estar vazio");
    return; 
  }

  if (!Number.isInteger(Number(referenceExpiry))) {
    showErrorModal("Erro: Por favor, use apenas números inteiros (sem casas decimais).");
    return;
  }

  //devem preencher com as vossas credenciais de qualidade
  const credential_obj = {
    terminalId: "",
    entity: "",
    clientId: "",
    bearerToken: "",
    paymentMethods:JSON.stringify(methods),
    referenceExpiry: referenceExpiry,
    referenceExpiryUnit: referenceExpiryUnit,
    isDummyCustomer: isDummyCustomer.toString(),
    AllMethodsPay: AllMethodsPay,
    LayoutVersion: LayoutVersion
  };

  localStorage.setItem('credential_default', JSON.stringify(credential_obj));
  localStorage.setItem('default', '0');

  showSuccessModal("Configurações guardadas com sucesso!");

}

//Ao abrir a pagina ele vai buscar ao LocalStorage as opções certas
function restoreFromLocalStorage() {
    
  const savedMethods = credentialDefaultObj.paymentMethods;
  const AllMethodsPay = credentialDefaultObj.AllMethodsPay;
  const referenceExpiry = credentialDefaultObj.referenceExpiry;
  const referenceExpiryUnit = credentialDefaultObj.referenceExpiryUnit;
  
  const LayoutVersion = credentialDefaultObj.LayoutVersion;
  document.getElementById("LayoutVersion").value = LayoutVersion;

  const select = document.getElementById('paymentMethods');
    Array.from(select.options).forEach(opt => {
    opt.selected = savedMethods.includes(opt.value);
  });


  handlePaymentMethodChange();
  toggleAllMethodsPayRestored(AllMethodsPay);
}

window.addEventListener('DOMContentLoaded', restoreFromLocalStorage);
