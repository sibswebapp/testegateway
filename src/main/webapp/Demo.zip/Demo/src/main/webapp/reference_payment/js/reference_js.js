document.addEventListener("DOMContentLoaded", async function () {

    function getQueryParam(param) {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get(param);
    }

    // variavies globais
    const credential_default_variable = JSON.parse(localStorage.getItem('credential_default'))

    let encodedPaymentMethods

    const token = credential_default_variable.bearerToken;
    const clientId = credential_default_variable.clientId;
    const terminalId = credential_default_variable.terminalId;
    const entity = credential_default_variable.entity;
    const isDummyCustomer = credential_default_variable.isDummyCustomer;
    const ServerToServer = credential_default_variable.ServerToServer;
    const paymentMethods= credential_default_variable.paymentMethods;
    const gatewayVersion= credential_default_variable.gatewayVersion;
                
        
    encodedPaymentMethods = encodeURIComponent(paymentMethods);

    const paymentId = getQueryParam("id");
    const token_payment = token;
    const clientId_payment = clientId;

    const transactionID = getQueryParam("id");
    const referenceDiv = document.getElementById("service-reference");

    if (!transactionID) {
        referenceDiv.innerHTML = '<div class="alert alert-danger">ID da transação não encontrado.</div>';
        return;
    }

    // Fazer o GET status para saber os campos e o estado do pagamento
    version = gatewayVersion === "1" ? "v1" : "v2";
    const apiUrl = `https://spg.qly.site1.sibs.pt/api/${version}/payments/${paymentId}/status`;

    const headers = {
        Authorization: `Bearer ${token_payment}`,
        "X-IBM-Client-Id": clientId_payment,
        "Content-Type": "application/json",
        Accept: "application/json",
    };

    try {
        const response = await fetch(apiUrl, {
            method: "GET",
            headers: headers,
        });

        if (!response.ok) {
            throw new Error(`Erro na requisição: ${response.status}`);
        }

        const data = await response.json();

        referenceDiv.innerHTML = `
            <div class="card shadow-sm mt-4 border-0 rounded-3">
                <div class="card-header bg-primary text-white text-center fw-semibold">
                    Detalhes de Pagamento
                </div>
                <div class="card-body">
                    <ul class="list-group list-group-flush text-center">

                        <li class="list-group-item d-flex justify-content-between">
                            <span><strong>Entidade</strong></span>
                            <span>${data.paymentReference.paymentEntity}</span>
                        </li>

                        <li class="list-group-item d-flex justify-content-between">
                            <span><strong>Referência</strong></span>
                            <span>${data.paymentReference.reference}</span>
                        </li>

                        <li class="list-group-item d-flex justify-content-between">
                            <span><strong>Montante</strong></span>
                            <span class="fw-bold text-primary">${data.amount.value} €</span>
                        </li>

                        <li class="list-group-item d-flex justify-content-between">
                            <span><strong>Validade</strong></span>
                            <span>${new Date(data.paymentReference.expireDate).toLocaleDateString()}</span>
                        </li>

                        <li class="list-group-item text-center mt-2">
                            ${(() => {
                                if (data.paymentStatus === "Pending") {
                                    return `<span class="badge bg-warning text-dark px-3 py-2">Estado do pagamento: Pendente</span>`;
                                } else if (data.paymentStatus === "Declined") {
                                    return `<span class="badge bg-danger px-3 py-2">Estado do pagamento: Sem sucesso</span>`;
                                } else if (data.paymentStatus === "Success") {
                                    return `<span class="badge bg-success px-3 py-2">Estado do pagamento: Sucesso</span>`;
                                } else {
                                    return `<span class="badge bg-secondary px-3 py-2">${data.paymentStatus}</span>`;
                                }
                            })()}
                        </li>

                    </ul>
                </div>
            </div>
        `;
    } catch (error) {
        console.error("Erro ao gerar referência de pagamento:", error);
        referenceDiv.innerHTML = '<div class="alert alert-danger">Erro ao gerar referência de pagamento.</div>';
    }
});