 document.addEventListener("DOMContentLoaded", async function () {
      
      function getQueryParam(param) {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get(param);
      }

      // variavies globais
      const credential_default_variable = JSON.parse(localStorage.getItem('credential_default'))

      let encodedPaymentMethods
  
      const  token_payment = credential_default_variable.bearerToken;
      const  clientId_payment = credential_default_variable.clientId;
      const  terminalId = credential_default_variable.terminalId;
      const  entity = credential_default_variable.entity;
      const  isDummyCustomer = credential_default_variable.isDummyCustomer;
      const  ServerToServer = credential_default_variable.ServerToServer;
      const  paymentMethods = credential_default_variable.paymentMethods;
      const  gatewayVersion = credential_default_variable.gatewayVersion;

      encodedPaymentMethods = encodeURIComponent(paymentMethods);
      const paymentId = getQueryParam("id");

      if (!paymentId) {
        document.getElementById("payment-status").innerHTML =
          '<div class="alert alert-danger">ID do pagamento não encontrado.</div>';
        return;
      }

      const version = gatewayVersion === "1" ? "v1" : "v2";
      const apiUrl = `https://spg.qly.site1.sibs.pt/api/${version}/payments/${paymentId}/status`;
    
      const headers = {
        Authorization: `Bearer ${token_payment}`,
        "X-IBM-Client-Id": clientId_payment,
        "Content-Type": "application/json",
        Accept: "application/json",
      };

      try {
        const response = await fetch(apiUrl, {
          method: "GET",
          headers: headers,
        });

        if (!response.ok) {
          throw new Error(`Erro na requisição: ${response.status}`);
        }

        const data = await response.json();

        if (data.paymentStatus === "Success") {
          document.getElementById("payment-status").innerHTML = `<div class="alert alert-success d-flex flex-column align-items-center text-center" role="alert">
                            <svg class="bi mb-2" width="50" height="50" role="img" aria-label="Success:">
                                <use href="#check-circle-fill"/>
                            </svg>
                            <div>
                                <strong>Status do pagamento:</strong> ${data.paymentStatus}
                            </div>
                        </div>`;
        } else {
          document.getElementById("payment-status").innerHTML = `<div class="alert alert-danger d-flex flex-column align-items-center text-center" role="alert">
                            <svg class="bi mb-2" width="50" height="50" role="img" aria-label="Erro:">
                                <use href="#exclamation-triangle-fill"/>
                            </svg>
                            <div>
                                <strong>Status do pagamento:</strong> ${data.paymentStatus}
                            </div>
                            <div>
                                <strong>Descrição:</strong>${data.transactionStatusDescription}
                            </div>
                        </div>`;
        }
      } catch (error) {
        console.error("Erro ao buscar status do pagamento:", error);
        document.getElementById("payment-status").innerHTML =
          '<div class="alert alert-danger">Erro ao buscar status do pagamento.</div>';

    
      }
    });